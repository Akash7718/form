<?php
// MySQL database connection settings
$host = "localhost";
$username = "your_username";
$password = "your_password";
$database = "your_database";

// Establish the database connection
$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Insert user details into the database
$name = $_POST['name'];
$age = $_POST['age'];
$weight = $_POST['weight'];
$email = $_POST['email'];

$sql = "INSERT INTO users (name, age, weight, email) VALUES ('$name', '$age', '$weight', '$email')";
if (mysqli_query($conn, $sql)) {
    $userId = mysqli_insert_id($conn);

    // Upload and insert the health report PDF file
    $healthReportFile = $_FILES['healthReport'];
    $healthReportFileName = $healthReportFile['name'];
    $healthReportTmpName = $healthReportFile['tmp_name'];
    $healthReportError = $healthReportFile['error'];

    if ($healthReportError === UPLOAD_ERR_OK) {
        $destination = "uploads/" . $healthReportFileName;
        move_uploaded_file($healthReportTmpName, $destination);

        $sql = "UPDATE users SET health_report = '$destination' WHERE id = '$userId'";
        mysqli_query($conn, $sql);
    }
}

mysqli_close($conn);
?>
