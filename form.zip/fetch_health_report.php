<?php
// MySQL database connection settings
$host = "localhost";
$username = "your_username";
$password = "your_password";
$database = "your_database";

// Establish the database connection
$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_GET['email'];

// Fetch the health report file path based on the email ID
$sql = "SELECT health_report FROM users WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $healthReportPath = $row['health_report'];

    // Send the PDF file as a download to the user
    header("Content-Type: application/pdf");
    header("Content-Disposition: attachment; filename=\"health_report.pdf\"");
    readfile($healthReportPath);
} else {
    echo "No health report found for the given email ID.";
}

mysqli_close($conn);
?>
